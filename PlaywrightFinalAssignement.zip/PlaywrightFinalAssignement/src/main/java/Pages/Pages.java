package Pages;

import java.util.Properties;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class Pages {
public static Page page;
public static Properties pr;
public static String Logo="//img[@alt='Website for automation practice']";
public static String SignupLoginButton="//a[@href='/login']";
public static String UsernameLocator="//input[@data-qa='login-email']";
public static String PasswordLocator="//input[@placeholder='Password']";
public static String Login="//button[@data-qa='login-button']";
public static String Products="//a[@href='/products']";
public static String FirstProduct="//img[@src='/get_product_picture/1']";
public static String AddTOCart1="(//a[contains(text(),'Add to cart')])[2]";


public static String ViewCart="//a[contains(.,'View Cart')]";
public static String Checkout="Proceed To Checkout";
public static String PlaceOrder="//a[@href='/payment']";
public static String CardName="//input[@name='name_on_card']";
public static String CardNumber="//input[@name='card_number']";
public static String CVC="//input[@placeholder='ex. 311']";
public static String ExpireMonth="//input[@placeholder='MM']";
public static String ExpireYear="//input[@placeholder='YYYY']";
public static String Pay="//button[@id='submit']";

public Pages(Properties pr, Page page2) {
	this.page=page2;
	this.pr=pr;
}
// Click on  SignupLogin button
public void SignupLogin() {
	page.locator(Pages.SignupLoginButton).click();
}

//Pass the username and password and click on login button
public void login(String username,String password) {
	page.locator(Pages.UsernameLocator).fill(username);
	page.locator(Pages.PasswordLocator).fill(password);
	Locator login=page.locator(Pages.Login);
	login.click();
}

//Click on Products button
public void Products() {
	page.click(Pages.Products);
}
//Add first Product
public void AddFirstProduct() {	
	Locator Product1=page.locator(Pages.FirstProduct);
	Product1.hover();
	page.click(Pages.AddTOCart1);
}

// Click on View Cart
public void ViewCart() {
	page.click(Pages.ViewCart);
	
}
// Click on checkout
public void CheckOut() {
	Locator checkout =page.getByText(Pages.Checkout);
	checkout.click();
}
// Scroll down to end
public void ScrollDown() {
	while (true) {
		boolean hasScrolled = (boolean) page.evaluate("() => { const scrolled = window.scrollY; window.scrollBy(0, window.innerHeight); return scrolled !== window.scrollY; }"
				);

		// If scrolling didn't occur means the user reached at the last then the loop will be break
		if (!hasScrolled) {
			break;
		}
	}
}
//Place the order
public void PlaceOrder() {
	page.click(Pages.PlaceOrder);
}
//Enter the details and pay
public void EnterCardDetails(String CardName,String CardNumber, String CVCValue, String ExpireMonth, String ExpireYear) {
	page.locator(Pages.CardName).fill(CardName);
	page.locator(Pages.CardNumber).fill(CardNumber);
	page.locator(Pages.CVC).fill(CVCValue);
	page.locator(Pages.ExpireMonth).fill(ExpireMonth);
	page.locator(Pages.ExpireYear).fill(ExpireYear);
	page.click(Pages.Pay);
}

}
