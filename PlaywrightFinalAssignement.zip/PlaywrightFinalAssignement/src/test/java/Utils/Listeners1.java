package Utils;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.microsoft.playwright.Page;

import Base.Page1;

public class Listeners1 extends Page1 implements ITestListener  {

	public Listeners1() throws IOException {
		super();
	}

	private static String getTestMethodName(ITestResult result) {
		return result.getMethod().getConstructorOrMethod().getName();

	}
	
	@Override
	public void onTestStart(ITestResult result) {
		
		System.out.println("Test is started with " + getTestMethodName(result));
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println( getTestMethodName(result)+ " method is pass");
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("Failed test method is " + getTestMethodName(result)+ "Screenshot is captured as I added assertion Assert.assertTrue(false)" );
		saveFailureScreenshot(page);
		
	}
	
	public void  saveFailureScreenshot(Page page) { 
		Path path = Paths.get("Screenshot\\Screenshot.png");
		page.screenshot(new Page.ScreenshotOptions().setPath(path));
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestSkipped(result);
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestFailedButWithinSuccessPercentage(result);
	}

	@Override
	public void onTestFailedWithTimeout(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestFailedWithTimeout(result);
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		ITestListener.super.onStart(context);
	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		ITestListener.super.onFinish(context);
	}

	
	
}
